// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

#pragma once

// C++ Standard Library Headers
#include <numbers>

// WPILIB Headers
#include <frc/Encoder.h>
#include <frc/controller/PIDController.h>
#include <frc/controller/ProfiledPIDController.h>
#include <frc/controller/SimpleMotorFeedforward.h>
#include <frc/kinematics/SwerveModulePosition.h>
#include <frc/kinematics/SwerveModuleState.h>
#include <frc/motorcontrol/PWMSparkMax.h>
#include <units/angular_velocity.h>
#include <units/angular_acceleration.h>
#include <units/time.h>
#include <units/velocity.h>
#include <units/voltage.h>

// REV Headers
#include <rev/CANSparkMax.h>
#include <rev/SparkMaxRelativeEncoder.h>

// CTRE Headers
#include <ctre/Phoenix.h>

class SwerveModule {
 public:
  /*** Constructor ***/
  SwerveModule(int driveMotorChannel, int turningMotorChannel, int turningEncoderChannel, 
    units::radian_t offset, bool invertDriveMotor, bool invertTurningMotor);

  /*** Interface Methods ***/
  frc::SwerveModuleState GetState(); //const;

  frc::SwerveModulePosition GetPosition(); //const;

  void SetDesiredState(const frc::SwerveModuleState& state);

  void SetDesiredStateSimple(const frc::SwerveModuleState& state);
  /******/

 private:
  /*** Constants ***/
  static constexpr double kWheelRadius = 0.0508; //meters - wheels are 4" OD

  static constexpr int kEncoderResolution = 4096;

  static constexpr auto kModuleMaxAngularVelocity =
      std::numbers::pi * 1_rad_per_s;  // radians per second

  static constexpr auto kModuleMaxAngularAcceleration =
      std::numbers::pi * 2_rad_per_s_sq;  // radians per second^2

  /*** Motors ***/
  rev::CANSparkMax m_driveMotor;
  rev::SparkMaxPIDController m_drivePID;
  rev::CANSparkMax m_turningMotor;
  rev::SparkMaxPIDController m_turningPID;
  double kP = 0.1, kI = 1e-4, kD = 1, kIz = 0, kFF = 0, kMaxOutput = 1, kMinOutput = -1;
  double kMaxSpeed = 3; //mps

  /*** Encoders ***/
  rev::SparkMaxRelativeEncoder m_driveEncoder;
  WPI_CANCoder  m_turningEncoder;
  units::radian_t turningencoderoffset;

  /*** Controllers ***/
  frc2::PIDController m_drivePIDController{1.0, 0, 0}; 
  frc::ProfiledPIDController<units::radians> m_turningPIDController{
      1.0,
      0.0,
      0.0,
      {kModuleMaxAngularVelocity, kModuleMaxAngularAcceleration}};

  frc::SimpleMotorFeedforward<units::meters> m_driveFeedforward{1_V, 0.5_V / 1_mps}; //{1_V, 3_V / 1_mps};
  frc::SimpleMotorFeedforward<units::radians> m_turnFeedforward{1_V, 0.5_V / 1_rad_per_s};
  /******/
};