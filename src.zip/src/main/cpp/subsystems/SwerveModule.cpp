// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.


// C++ Standard Library Headers
#include <numbers>

// WPILIB Headers
#include <frc/geometry/Rotation2d.h>
#include <units/length.h>
#include <frc/smartdashboard/SmartDashboard.h>

// REV Headers
#include <rev/CANSparkMax.h>

// Project Headers
#include "subsystems/SwerveModule.h"


SwerveModule::SwerveModule(const int driveMotorChannel,
                           const int turningMotorChannel,
                           const int turningEncoderChannel,
                           const units::radian_t offset,
                           const bool invertDriveMotor,
                           const bool invertTurningMotor)
    : m_driveMotor(driveMotorChannel,rev::CANSparkMaxLowLevel::MotorType::kBrushless),
      m_driveEncoder(m_driveMotor.GetEncoder()),
      m_turningMotor(turningMotorChannel,rev::CANSparkMaxLowLevel::MotorType::kBrushless),
      m_turningEncoder(turningEncoderChannel),
      m_drivePID(m_driveMotor.GetPIDController()),
      m_turningPID(m_turningMotor.GetPIDController()) {
  
  /*** Configure drive wheel encoder ***/
  m_driveEncoder.SetPositionConversionFactor(2 * std::numbers::pi * kWheelRadius); //Distance travelled per encoder pulse - Native position output from encoder is rev
  m_driveEncoder.SetVelocityConversionFactor(2 * std::numbers::pi * kWheelRadius / 60); //Velocity conversion factor - Native velocity output from encoder is rpm
  
  if (invertDriveMotor){
    m_driveMotor.SetInverted(true);
  }
  else{
    m_driveMotor.SetInverted(false);
  }
  
  /*** Configure turning encoder ***/
  m_turningEncoder.ConfigFeedbackCoefficient(2 * std::numbers::pi / kEncoderResolution,
      "rad", ctre::phoenix::sensors::SensorTimeBase::PerSecond); //Radians per encoder pulse
  m_turningEncoder.ConfigAbsoluteSensorRange(ctre::phoenix::sensors::AbsoluteSensorRange::Signed_PlusMinus180); //Set range to -180 to 180 deg
  m_turningEncoder.ConfigSensorInitializationStrategy(ctre::phoenix::sensors::SensorInitializationStrategy::BootToAbsolutePosition); //Use absolute encoder
  turningencoderoffset = offset;

  if (invertTurningMotor){
    m_turningMotor.SetInverted(true);
  }
  else{
    m_turningMotor.SetInverted(false);
  }
  
  m_drivePID.SetP(kP);
  m_drivePID.SetI(kI);
  m_drivePID.SetD(kD);
  m_drivePID.SetFF(kFF);
  m_drivePID.SetIZone(kIz);
  m_drivePID.SetOutputRange(kMinOutput,kMaxOutput);

  m_turningPID.SetP(kP);
  m_turningPID.SetI(kI);
  m_turningPID.SetD(kD);
  m_turningPID.SetFF(kFF);
  m_turningPID.SetIZone(kIz);
  m_turningPID.SetOutputRange(kMinOutput,kMaxOutput);
 
  // Limit the PID Controller's input range between -pi and pi and set the input to be continuous.
  m_turningPIDController.EnableContinuousInput(
      -units::radian_t{std::numbers::pi}, units::radian_t{std::numbers::pi});
} 
  
frc::SwerveModuleState SwerveModule::GetState() {
  return {units::meters_per_second_t{m_driveEncoder.GetVelocity()},
          units::radian_t{m_turningEncoder.GetPosition()}-turningencoderoffset};
}

frc::SwerveModulePosition SwerveModule::GetPosition() {
  return {units::meter_t{m_driveEncoder.GetPosition()},
          units::radian_t{m_turningEncoder.GetPosition()}-turningencoderoffset};
}

void SwerveModule::SetDesiredState(const frc::SwerveModuleState& referenceState) {
  // Optimize the reference state to avoid spinning further than 90 degrees
  const auto state = frc::SwerveModuleState::Optimize(
      referenceState, units::radian_t{m_turningEncoder.GetPosition()}-turningencoderoffset);

  // Calculate the drive output from the drive PID controller.
  const auto driveOutput = m_drivePIDController.Calculate(
      m_driveEncoder.GetVelocity(), state.speed.value());

  const auto driveFeedforward = m_driveFeedforward.Calculate(state.speed);

  // Calculate the turning motor output from the turning PID controller.
  const auto turnOutput = m_turningPIDController.Calculate(
      units::radian_t{m_turningEncoder.GetPosition()}-turningencoderoffset, state.angle.Radians());

  const auto turnFeedforward = m_turnFeedforward.Calculate(
      m_turningPIDController.GetSetpoint().velocity); //Should this use the set point??

  frc::SmartDashboard::PutNumber("Drive PID", driveOutput);
  frc::SmartDashboard::PutNumber("DriveFeed Foorward", driveFeedforward.value());
  frc::SmartDashboard::PutNumber("Turn Output", turnOutput);
  frc::SmartDashboard::PutNumber("TurnFeed Forward", turnFeedforward.value());

  // Set the motor outputs.
  //m_driveMotor.SetVoltage(units::volt_t{driveOutput} + driveFeedforward);
  //m_turningMotor.SetVoltage(units::volt_t{turnOutput} + turnFeedforward);
  m_driveMotor.SetVoltage(units::volt_t{driveOutput});
  m_turningMotor.SetVoltage(units::volt_t{turnOutput});
}

void SwerveModule::SetDesiredStateSimple(const frc::SwerveModuleState& referenceState) {
  // Optimize the reference state to avoid spinning further than 90 degrees
  const auto state = frc::SwerveModuleState::Optimize(
      referenceState, units::radian_t{m_turningEncoder.GetPosition()}-turningencoderoffset);

  double steerAng = state.angle.Radians().value();
  //double steerCnts = steerAng * kEncoderResolution;
  m_turningPID.SetReference(steerAng, rev::CANSparkMax::ControlType::kPosition);

  double driveSpeed = state.speed.value();
  driveSpeed = driveSpeed / kMaxSpeed;
  m_drivePID.SetReference(driveSpeed, rev::CANSparkMax::ControlType::kDutyCycle);

}