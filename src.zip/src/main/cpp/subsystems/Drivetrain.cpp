// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

// WPILIB Headers
#include <frc/smartdashboard/SmartDashboard.h>

// Project Headers
#include "subsystems/Drivetrain.h"


Drivetrain::Drivetrain(){
  m_gyro.Reset(); 
}

Drivetrain::~Drivetrain(){}

void Drivetrain::Periodic(){
  // Update swerve drive odometry
  UpdateOdometry();

  // Output drivetrain data to SmartDashboard
  frc::SmartDashboard::PutNumber("FL Angle", m_frontLeft.GetPosition().angle.Radians().value());
  frc::SmartDashboard::PutNumber("FR Angle", m_frontRight.GetPosition().angle.Radians().value());
  frc::SmartDashboard::PutNumber("BL Angle", m_backLeft.GetPosition().angle.Radians().value());
  frc::SmartDashboard::PutNumber("BR Angle", m_backRight.GetPosition().angle.Radians().value());

  frc::SmartDashboard::PutNumber("FL Distance", m_frontLeft.GetPosition().distance.value());
  frc::SmartDashboard::PutNumber("FR Distance", m_frontRight.GetPosition().distance.value());
  frc::SmartDashboard::PutNumber("BL Distance", m_backLeft.GetPosition().distance.value());
  frc::SmartDashboard::PutNumber("BR Distance", m_backRight.GetPosition().distance.value());

  frc::SmartDashboard::PutNumber("Gyro", m_gyro.GetAngle());

  frc::SmartDashboard::PutNumber("Yaw", m_gyro.GetYaw());
  frc::SmartDashboard::PutNumber("Pitch", m_gyro.GetPitch());
  frc::SmartDashboard::PutNumber("Roll", m_gyro.GetRoll());
}

void Drivetrain::SwerveDrive(double _xSpeed,
                       double _ySpeed,
                       double _rot, bool fieldRelative) {

    units::meters_per_second_t xSpeed{_xSpeed};
    units::meters_per_second_t ySpeed{_ySpeed};
    units::radians_per_second_t rot{_rot};                        

    frc::SmartDashboard::PutNumber("X speed", _xSpeed);
    frc::SmartDashboard::PutNumber("Y speed", _ySpeed);
    frc::SmartDashboard::PutNumber("Rotation", _rot);

    //Positive X is toward robot front, positive y is to left of robot

    // Get the x speed. We are inverting this because Xbox controllers return
    // negative values when we push forward.
    //const auto xSpeed = -m_xSpeedLimiter.Calculate(
    //                        frc::ApplyDeadband(_xSpeed, 0.02)) *
    //                    Drivetrain::kMaxSpeed;

    // Get the y speed or sideways/strafe speed. We are inverting this because
    // we want a positive value when we pull to the left. Xbox controllers
    // return positive values when you pull to the right by default.
    //const auto ySpeed = -m_ySpeedLimiter.Calculate(
    //                        frc::ApplyDeadband(_ySpeed, 0.02)) *
    //                    Drivetrain::kMaxSpeed;

    // Get the rate of angular rotation. We are inverting this because we want a
    // positive value when we pull to the left (remember, CCW is positive in
    // mathematics). Xbox controllers return positive values when you pull to
    // the right by default.
    //const auto rot = -m_rotLimiter.Calculate(
    //                     frc::ApplyDeadband(_rot, 0.02)) *
    //                 Drivetrain::kMaxAngularSpeed;

    auto states = m_kinematics.ToSwerveModuleStates(
        fieldRelative ? frc::ChassisSpeeds::FromFieldRelativeSpeeds(
                            xSpeed, ySpeed, rot, m_gyro.GetRotation2d())
                      : frc::ChassisSpeeds{xSpeed, ySpeed, rot});

    //Decrease all wheel speeds proportionately if any exceed the max speed
    m_kinematics.DesaturateWheelSpeeds(&states, kMaxSpeed);

    auto [fl, fr, bl, br] = states;

    //m_frontLeft.SetDesiredState(fl);
    //m_frontRight.SetDesiredState(fr);
    //m_backLeft.SetDesiredState(bl);
    //m_backRight.SetDesiredState(br);
    m_frontLeft.SetDesiredStateSimple(fl);
    m_frontRight.SetDesiredStateSimple(fr);
    m_backLeft.SetDesiredStateSimple(bl);
    m_backRight.SetDesiredStateSimple(br);
}

void Drivetrain::UpdateOdometry() {
  m_odometry.Update(m_gyro.GetRotation2d(),
                    {m_frontLeft.GetPosition(), m_frontRight.GetPosition(),
                     m_backLeft.GetPosition(), m_backRight.GetPosition()});
}