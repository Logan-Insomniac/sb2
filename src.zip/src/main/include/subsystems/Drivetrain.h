// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

#pragma once

// C++ Standard Library Headers
#include <numbers>

// WPILIB Headers
#include <frc/AnalogGyro.h>
#include <frc/geometry/Translation2d.h>
#include <frc/kinematics/SwerveDriveKinematics.h>
#include <frc/kinematics/SwerveDriveOdometry.h>
#include <frc/filter/SlewRateLimiter.h>
#include <frc2/command/SubsystemBase.h>
#include <units/dimensionless.h>
#include <frc/SPI.h>
#include <units/angle.h>

// NAVX Headers
#include "subsystems/NavxGyro/AHRS.h"

// Project Headers
#include "SwerveModule.h"

/**
 * Represents a swerve drive style drivetrain.
 */
class Drivetrain : public frc2::SubsystemBase {
 public:
  /*** Default contstructor and destructor - needed to prevent build errors ***/
  Drivetrain();
  ~Drivetrain();

  /*** Interface Methods ***/
  void SwerveDrive(double xSpeed,
             double ySpeed, 
             double rot,
             bool fieldRelative);

  void UpdateOdometry();

  void Periodic() override;

  /*** Public Constants ***/
  static constexpr units::meters_per_second_t kMaxSpeed = 3.0_mps;  // 3 meters per second
  static constexpr units::radians_per_second_t kMaxAngularSpeed{std::numbers::pi};  // 1/2 rotation per second

 private:
  /*** Wheel locations relative to robot center ***/
  //Looking from center to front of robot...
  //Positive x is straight ahead
  //Positive y is to the left
  frc::Translation2d m_frontLeftLocation{+0.2286_m, +0.2286_m};
  frc::Translation2d m_frontRightLocation{+0.2286_m, -0.2286_m};
  frc::Translation2d m_backRightLocation{-0.2286_m, -0.2286_m};
  frc::Translation2d m_backLeftLocation{-0.2286_m, +0.2286_m};

  /*** Create SwerveModules - map to motor controllers and turning encoder */
  SwerveModule m_frontLeft{10, 11, 21, -2.954441_rad, false, false};
  SwerveModule m_frontRight{12, 13, 22, -0.840620_rad, true, false};
  SwerveModule m_backRight{14, 15, 23, -0.438718_rad, false, false};
  SwerveModule m_backLeft{16, 17, 24, -1.483356_rad, false, false};

  /*** NAVX Gyro ***/
  AHRS m_gyro{frc::SPI::Port::kMXP};

  /*** Rate limiters for x, y, angle commands ***/
  frc::SlewRateLimiter<units::dimensionless::scalar> m_xSpeedLimiter{3 / 1_s};
  frc::SlewRateLimiter<units::dimensionless::scalar> m_ySpeedLimiter{3 / 1_s};
  frc::SlewRateLimiter<units::dimensionless::scalar> m_rotLimiter{3 / 1_s};

  /*** Swerve Drive Mechanics ***/
  frc::SwerveDriveKinematics<4> m_kinematics{
      m_frontLeftLocation, m_frontRightLocation, 
      m_backLeftLocation, m_backRightLocation};

  frc::SwerveDriveOdometry<4> m_odometry{
      m_kinematics,
      m_gyro.GetRotation2d(),
      {m_frontLeft.GetPosition(), m_frontRight.GetPosition(),
       m_backLeft.GetPosition(), m_backRight.GetPosition()}};
};