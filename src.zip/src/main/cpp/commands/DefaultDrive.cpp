// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

#include "commands/DefaultDrive.h"

#include <utility>

DefaultDrive::DefaultDrive(Drivetrain* subsystem, std::function<double()> vx, std::function<double()> vy, std::function<double()> rot)
    : m_drive{subsystem}, m_xSpeed{std::move(vx)}, m_ySpeed{std::move(vy)}, m_rot{std::move(rot)} {

  AddRequirements({subsystem});
}

void DefaultDrive::Execute() {
  m_drive->SwerveDrive(m_xSpeed(), m_ySpeed(), m_rot(), true);
}